const exp = require("express");
const productApiObj = exp.Router();

productApiObj.use(exp.json());
const errorHandler = require("express-async-handler");
const jwt = require("jsonwebtoken");

const Product = require("../models/Product");

const bcryptjs = require("bcryptjs");

// cloudinary
const cloudinary = require("cloudinary").v2;
const { CloudinaryStorage } = require("multer-storage-cloudinary");
const multer = require("multer");
//const { date } = require("joi");


// const authSchema=require('../helpers/validation')

productApiObj.get(
  "/getproductsadventure",
  errorHandler(async (req, res) => {
    //console.log("getprodAdventure is working");

    let products = await Product.find({ type: "Adventure" });

    //console.log(products);
    res.send({ message: products });
  })
);
productApiObj.get(
  "/getproductsbiography",
  errorHandler(async (req, res) => {
    let products = await Product.find({ type: "Biography" });
    //console.log(products);
    res.send({ message: products });
  })
);
productApiObj.get(
  "/getproductsbusiness",
  errorHandler(async (req, res) => {
    let products = await Product.find({ type: "Business" });
    //console.log(products);
    res.send({ message: products });
  })
);
productApiObj.get(
  "/getproductscomputing",
  errorHandler(async (req, res) => {
    let products = await Product.find({ type: "Computing" });
    //console.log(products);
    res.send({ message: products });
  })
);
productApiObj.get(
  "/getproductscrime",
  errorHandler(async (req, res) => {
    let products = await Product.find({ type: "Crime" });
    //console.log(products);
    res.send({ message: products });
  })
);

productApiObj.get(
  "/getproductsfiction",
  errorHandler(async (req, res) => {
    let products = await Product.find({ type: "Fiction" });
    //console.log(products);
    res.send({ message: products });
  })
);
productApiObj.get(
  "/getproductshumour",
  errorHandler(async (req, res) => {
    let products = await Product.find({ type: "Humour" });
    //console.log(products);
    res.send({ message: products });
  })
);

productApiObj.get(
  "/getproductspolitics",
  errorHandler(async (req, res) => {
    let products = await Product.find({ type: "Politics" });
    //console.log(products);
    res.send({ message: products });
  })
);
productApiObj.get(
  "/getproductsreligion",
  errorHandler(async (req, res) => {
    let products = await Product.find({ type: "Religion" });
    //console.log(products);
    res.send({ message: products });
  })
);
productApiObj.get(
  "/getproductsromance",
  errorHandler(async (req, res) => {
    let products = await Product.find({ type: "Romance" });
    //console.log(products);
    res.send({ message: products });
  })
);
productApiObj.get(
  "/getproductsscience",
  errorHandler(async (req, res) => {
    let products = await Product.find({ type: "Science" });
    //console.log(products);
    res.send({ message: products });
  })
);

//const { date } = require("joi");

cloudinary.config({
  cloud_name: "dxjwuevta", 
  api_key: "815813133458844", 
  api_secret: "70H2LHBBcJOdOpfOZxZ8XO45wu4"
});

const storage=new CloudinaryStorage({
  cloudinary: cloudinary, 
  params: async (req,file)=>{
    return {
      folder: "bookimages", 
      public_id: file.fieldname + '-' + Date.now()
    }
  }
})

var upload=multer({storage:storage})



productApiObj.post(
  "/createproduct",
  upload.single('image'),
  errorHandler(async (req, res) => {
    //console.log("productApi is Working ");

    req.body=JSON.parse(req.body.productObj)
    req.body.image=req.file.path;
console.log(req.file.path.green)
    let productObj = req.body;

   //console.log("obj",productObj);

    let product = await Product.findOne({ prod_id: productObj.prod_id });
 
  //console.log(product)

    if (product == null) {
    
      //create product obj for product model
      let newproductObj = new Product({
    
        active:req.body.active,
        author: req.body.author,
        language: req.body.language,
        prod_desc: req.body.prod_desc,
        prod_id: req.body.prod_id,
        prod_name: req.body.prod_name,
        prod_pages: req.body.prod_pages,
        prod_price: req.body.prod_price,
        prod_quantity: req.body.prod_quantity,
        prod_weight: req.body.prod_weight,
        prod_year: req.body.prod_year,
        product_image:  req.body.image,
        type: req.body.type
      });
      //console.log(newproductObj);
      
      //save
      await newproductObj.save();
      //  console.log(product)
      res.send({ message: "product created" });
    } else {
      res.send({ message: "product already exist" });
    }
  })
);



module.exports = productApiObj;
