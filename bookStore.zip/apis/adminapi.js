const exp = require("express");
const adminApiObj = exp.Router();
adminApiObj.use(exp.json());
const errorHandler = require("express-async-handler");
const jwt = require("jsonwebtoken");
const Admin = require("../models/Admin");
const bcryptjs = require("bcryptjs");
// const authSchema=require('../helpers/validation')
adminApiObj.post(

  "/createadmin",

  errorHandler(async (req, res) => {
  

    let adminObj = req.body;
        
    let admin = await Admin.findOne({ username: adminObj.username });

    if (admin == null) {
      let hashedPassword = await bcryptjs.hash(req.body.password, 7);
      //create admin obj for Admin model
      let newAdminObj = new Admin({
        username: req.body.username,
        password: hashedPassword,
        email: req.body.email,
        products: req.body.products,
      
      });
      //save
      await newAdminObj.save();
      //  console.log(user)
      res.send({ message: "Admin created" });
    } else {
      res.send({ message: "Admin already existed" });
    }
  })
);

adminApiObj.post(
  "/updateproduct",
  errorHandler(async (req, res) => {
    updateObj = req.body;
    let admin =await Admin.updateOne(
      { username: updateObj[1] },
      {
        products: updateObj[0],
      },
      (err) => {
        console.log(err);
      }
    );


    console.log("admin is",admin)
  })
);
adminApiObj.post(
  "/login",
  errorHandler(async (req, res) => {
    let adminObj = req.body;
    // console.log(adminObj);

    let admin = await Admin.findOne({ username: adminObj.username });

    if (admin == null) {
      res.send({ message: "Invalid username" });
    } else {
    
      let status = await bcryptjs.compare(adminObj.password, admin.password);
      if (status) {
        let token = await jwt.sign({ username: admin.username }, "abcd", {
          expiresIn: 100,
        });
        res.send({
          message: "success",
          token: token,
          adminObj: JSON.stringify(admin.username),
        });
      } else {
        res.send({ message: "Invalid Password" });
      }
    }
  })
);

module.exports = adminApiObj;
