const exp = require("express");
const userApiObj = exp.Router();

userApiObj.use(exp.json());
const errorHandler = require("express-async-handler");
const jwt = require("jsonwebtoken")

const User = require("../models/User");

const bcryptjs = require("bcryptjs");

// const authSchema=require('../helpers/validation')

userApiObj.post(
  "/createuser",
  errorHandler(async (req, res) => {
    console.log("userApi is Working ");

    let userObj = req.body;

  

    let user = await User.findOne({ username: userObj.username });


    if (user == null) {
      let hashedPassword = await bcryptjs.hash(req.body.password, 7);
      //create user obj for user model
      let newUserObj = new User({
        username: req.body.username,
        password: hashedPassword,
        email: req.body.email,
      });
      //save
      await newUserObj.save();
      //  console.log(user)
      res.send({ message: "user created" });
    } else {
      res.send({ message: "User already existed" });
    }
  })
);
userApiObj.post(

  "/login",
  errorHandler(async(req,res)=>{


    let userObj=req.body;
    console.log(userObj);
    
    let user =await  User.findOne({username:userObj.username});

if(user==null){

  res.send({message:"Invalid username"})
}
else{

  let status = await bcryptjs.compare(userObj.password,user.password)
 
  if(status){

  let token =await jwt.sign({username:user.username},"abcd",{expiresIn:100})


  res.send({message:"success",
   token:token,
   userObj:JSON.stringify(user.username)
 

});

  }

  else{
    res.send({message:"Invalid Password"})
  }

}





  })
)

module.exports = userApiObj;
