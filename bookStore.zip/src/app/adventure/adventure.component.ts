import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-adventure',
  templateUrl: './adventure.component.html',
  styleUrls: ['./adventure.component.css']
})
export class AdventureComponent implements OnInit {

    constructor(private ds:DataService,private router:Router) { }
    adventureBooksFromdb

    ngOnInit(): void {

      
  this.ds.getProductsAdventure().subscribe(


    res=>{
      this.adventureBooksFromdb=res['message']
    },
    err=>{

      alert("something went wrong")
    })
    }

  



}
