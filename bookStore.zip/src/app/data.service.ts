import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  private subject = new Subject<any>();

  constructor(private hc: HttpClient) {}

  createUser(userObj): Observable<any> {
    return this.hc.post('/user/createuser', userObj);
  }

  createProduct(productObj):Observable<any>{
    return this.hc.post("/product/createproduct",productObj)
  }
  loginUser(loginObj): Observable<any> {
    return this.hc.post('/user/login', loginObj);
  }
  loginAdmin(loginObj): Observable<any> {
    return this.hc.post('/admin/login', loginObj);
  }

  sendloginState(loginState) {
   this.subject.next(loginState);

  }
  getProductsAdventure():Observable<any>{
    return this.hc.get('/product/getproductsadventure')
  }
  createAdmin(adminObj): Observable<any> {
    return this.hc.post('/admin/createadmin', adminObj);
  }

  receiveloginState(): Observable<any> {
    return this.subject.asObservable();
  }


  updateAdminProducts(id):Observable<any>{

    return this.hc.post("/admin/updateproduct",id);
  }



  // service to get books based on category

  
  getProductsBiography():Observable<any>{
    return this.hc.get('/product/getproductsbiography')
  }
  getProductsBusiness():Observable<any>{
    return this.hc.get('/product/getproductsbusiness')
  }
  getProductsComputing():Observable<any>{
    return this.hc.get('/product/getproductscomputing')
  }
  getProductsCrime():Observable<any>{
    return this.hc.get('/product/getproductscrime')
  }
  getProductsFiction():Observable<any>{
    return this.hc.get('/product/getproductsfiction')
  }
  getProductsHumour():Observable<any>{
    return this.hc.get('/product/getproductshumour')
  }
  getProductsPolitics():Observable<any>{
    return this.hc.get('/product/getproductspolitics')
  }
  getProductsReligion():Observable<any>{
    return this.hc.get('/product/getproductsreligion')
  }
  getProductsRomance():Observable<any>{
    return this.hc.get('/product/getproductsromance')
  }
  getProductsScience():Observable<any>{
    return this.hc.get('/product/getproductsscience')
  }


}
