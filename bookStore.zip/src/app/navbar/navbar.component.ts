import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { boolean } from 'joi';
import { Subscription } from 'rxjs';
import { DataService } from '../data.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit,OnDestroy {
  username:any

  constructor(private ds: DataService,private router:Router) { }

  logStatus:boolean;

 

  $subs:Subscription;

  redirect(){
    this.router.navigateByUrl('/home')
  }
 
  loggedin(){

    this.username=localStorage.getItem("username")

 return localStorage.getItem('token')

  }

  usertype(){
    let type = localStorage.getItem("Usertype");
    if(type=="Admin"){
      return 0;

    }

    else{
      return 1;
    }
  }
  ngOnInit(): void {
      this.$subs= this.ds.receiveloginState().subscribe(d=>{
      this.logStatus=d;

      console.log("Harsha",this.username)
      
      
  
    })




  }

  ngOnDestroy(){
    this.$subs.unsubscribe();
  }


  logOutUser(){

    localStorage.removeItem('token')
localStorage.removeItem('username')
    this.logStatus=false;

    this.router.navigateByUrl("/login")


  }




  
  openNav() {
    document.getElementById("mySidenav").style.width = "250px";
  }

  
   closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }
  




}
