import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountComponent } from './account/account.component';
import { AddnewComponent } from './addnew/addnew.component';
import { AdmindashComponent } from './admindash/admindash.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ProductsComponent } from './products/products.component';
import { RegisterComponent } from './register/register.component';
import { SalesinfoComponent } from './salesinfo/salesinfo.component';
import { StoreComponent } from './store/store.component';

import { UserdashComponent} from './userdash/userdash.component'

const routes: Routes = [
{ path: '', pathMatch: 'full', redirectTo: 'home' },
{path:"home",component: HomeComponent},
{path:"login",component:LoginComponent},
{path:"register",component:RegisterComponent},
{path:"userdash/:username",component: UserdashComponent },
{path:"account",component:AccountComponent},
{path:"adminprofile",component:AdminprofileComponent},

{path:"admindash/:username",component:AdmindashComponent,children:[



  {path:"adminprofile",component:AdminprofileComponent},
  { path :"products",component:ProductsComponent},
  { path :"salesinfo",component:SalesinfoComponent},
  { path:"addnew",component:AddnewComponent } ,


  {path:"store",component:StoreComponent}

]  },
{path:"store",component:StoreComponent},

{path: '**', redirectTo: 'pagenotfound'}


];

@NgModule({
  // path mounting strategy
  imports: [RouterModule.forRoot(routes,{useHash:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
