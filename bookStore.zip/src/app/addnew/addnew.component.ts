import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { boolean } from 'joi';
import { DataService } from '../data.service';

@Component({
  selector: 'app-addnew',
  templateUrl: './addnew.component.html',
  styleUrls: ['./addnew.component.css']
})

export class AddnewComponent implements OnInit {
  file:File; 
 username:string
 sendData



  typeArray:Array<String>
   typeLanguage:Array<String>



   constructor(private ds: DataService,private router:Router ) { }

  addimage(event){
    this.file=event.target.files[0]
  }


formData=new FormData()

  ngOnInit(): void {

    this.typeArray=["Adventure", "Biography"]

    this.typeLanguage=["English", "Hindi"]
  }

  
validity:boolean=false


dataArray:Array<any>

  addProd(ref){

    console.log(ref.status)
    if(ref.status=="VALID"){


        

      
   this.dataArray=ref.value
   let productObj=ref.value
   this.formData.append("image",this.file,this.file.name)
   this.formData.append("productObj",JSON.stringify(productObj))

  

   ref.value.active="true"

// console.log("id is ",productObj.prod_id)

let localData=localStorage.getItem('username')

//  this.updateField= Object.assign(productObj.prod_id, JSON.parse(localData));
//  merge(productObj.prod_id, localData)



this.username=localData.replace(/['"]+/g, '')

this.sendData=[productObj.prod_id,this.username]



   this.ds.updateAdminProducts(this.sendData).subscribe(

 res=>{},

 err=>{}







   )
    this.ds.createProduct(this.formData).subscribe(
     
     res=>{
      console.log("response", res['message'])
     if(res['message']=="product created")
      alert("product created succcessfully")
      this.router.navigateByUrl("/store")

     if(res['message']=="product already exist"){
       alert("product already exist please add different prodcut")
     } 

     },
     err=>{
       alert("something is went wrong in proiduct crreation")

     }



    ) 
      

   
 



        

    this.validity=false
    }
 else{
  
  console.log("wrong ",ref.value)

   this.validity=true
 }

    
  }

}
