import {
  Component,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChange,
  SimpleChanges,
} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { DataService } from '../data.service';
declare var $: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  lists = ['User', 'Admin'];
  loginCheck: Boolean = false;
  isFormSubmitted = false;
  toastMessage: String="Please Select the Usertype";

  subscription: Subscription;
  constructor(private us: DataService, private router: Router) {}

  loginObj;

  loginStatus: boolean = localStorage.getItem('username') ? true : false;

  redirectRegister() {
    this.router.navigateByUrl('/register');
  }

  
  loginData() {
    console.log('LOGIN.TS', this.form.value);

    this.loginObj = this.form.value;

    if (this.loginObj.User == 'User') {
      delete this.loginObj.User;
      this.subscription = this.us.loginUser(this.loginObj).subscribe(
        (res) => {
          console.log(res['message']);

          if (res['message'] == 'success') {
            this.toastMessage = 'Successfull logged In!';

         


              localStorage.setItem('token', res['token']);

              this.loginStatus = true;
              localStorage.setItem('username', res['userObj']);
              this.loginCheck = true;
              this.us.sendloginState(this.loginStatus);
              this.router.navigateByUrl(`/userdash/${this.loginObj.username}`);



          }

          if (res['message'] == 'Invalid username') {
            // alert('Username is not valid Please Register');

            this.toastMessage = 'Username is not valid Please Register';

            // this.router.navigateByUrl('/register');
          }

          if (res['message'] == 'Invalid Password') {
            

            this.toastMessage = 'Incorrect  Password';
          }
        },

        (err) => {
          this.toastMessage = 'Maintainance issue';

        }
      );
    }

    if (this.loginObj.User == 'Admin') {
      // delete this.loginObj.User;
      this.us.loginAdmin(this.loginObj).subscribe(
        (res) => {
          console.log(res['message']);

          if (res['message'] == 'success') {
        

            console.log('2', this.loginStatus);
         
    
              this.router.navigateByUrl(`/admindash/${this.loginObj.username}`);
        

            localStorage.setItem('token', res['token']);
            localStorage.setItem('username', res['adminObj']);
            localStorage.setItem('Usertype', this.loginObj.User);

            this.loginStatus = true;
            this.us.sendloginState(this.loginStatus);
    

          }

          if (res['message'] == 'Invalid username') {

            
            this.toastMessage = 'Username is not valid Please Register';

            // this.router.navigateByUrl('/register');

            // this.router.navigateByUrl("/register")
          }

          if (res['message'] == 'Invalid Password') {
            this.toastMessage = 'Incorrect  Password';

            
          }
        },

        (err) => {}
      );
    }
  }

  form;
  ngOnInit(): void {
    $('.showtoast').click(function () {
      $('.toast').toast('show');
    });
    this.form = new FormGroup({
      // user: new FormControl('',[
      //      Validators.required
      // ]),

      // admin: new FormControl('',[
      //   Validators.required
      // ]),
      username: new FormControl('', [
        Validators.required,
        Validators.minLength(3),
      ]),

      password: new FormControl('', [
        Validators.required,
        Validators.minLength(3),
      ]),

      User: new FormControl(false),
      //  Admin:new FormControl(false),
    });
  }
}
