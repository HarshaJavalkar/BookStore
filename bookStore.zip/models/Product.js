
const mongoose = require("mongoose")

const productSchema = new mongoose.Schema({

    active:String,

    author: String,
    language: String,
    prod_desc: String,
    prod_id: Number,
    prod_name: String,
    prod_pages: Number,
    prod_price: Number,
    prod_quantity: Number,
    prod_weight: Number,
    prod_year: Number,
    product_image: String,
    type: String
})


//Create a model
const Product=mongoose.model("products",productSchema)

// Exports the model

module.exports=Product;